#include<bits/stdc++.h>

using i64 = long long;

auto main() ->int32_t {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);

	system("std.exe < 2.in > 2.out");
	system("std.exe < 3.in > 3.out");
	system("std.exe < 4.in > 4.out");
	system("std.exe < 5.in > 5.out");
	return 0;
}