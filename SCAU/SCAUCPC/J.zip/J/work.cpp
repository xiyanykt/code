#include<bits/stdc++.h>

using i64 = long long;

auto main() -> int32_t {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);

	// int c = 1;
	// while (true) {
	// 	system("py gen.py > f.in");
	// 	system("std.exe < f.in > std.out");
	// 	system("sol.exe < f.in > sol.out");
	// 	if (system("fc std.out sol.out > nul") != 0) {
	// 		break;
	// 	} else {
	// 		std::cout << std::format("test : {} \nAC\n", c++) << std::endl;
	// 	}
	// }
	// std::cout << std::format("test : {} \nWA\n", c) << std::endl;
	system("py gen.py > 2.in");
	system("std.exe < 2.in > 2.out");
	system("py gen.py > 3.in");
	system("std.exe < 3.in > 3.out");
	system("py gen.py > 4.in");
	system("std.exe < 4.in > 4.out");
	system("py gen.py > 5.in");
	system("std.exe < 5.in > 5.out");
	system("py gen.py > 6.in");
	system("std.exe < 6.in > 6.out");
	system("py gen.py > 7.in");
	system("std.exe < 7.in > 7.out");
	system("py gen.py > 8.in");
	system("std.exe < 8.in > 8.out");

	return 0;
}
